
lista = ["puede tener cadenas o enteros",1,2,"o mas listas","es modificable"]#Puede contener listas o diccionarios
tupla = (1,2,"Es como una lista pero no es modificable",2,["s",1]) #Puede contener listas o diccionarios
diccionario = {"clave":"valor","color":"Azul","precio":1900} #Puede contener listas o diccionarios

miset = set() #crea una lista

miset.add(1)
miset.add(1)

mi_lista=[1,1,1,1,2,2,2,2,3,3,3]
print(set(mi_lista))